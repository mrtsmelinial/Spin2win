export { default } from './WinDisplay'
