export { default } from './Statistic'
